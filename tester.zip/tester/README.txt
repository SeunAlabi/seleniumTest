The test driver used for this project was Selenium Driver. By all recommendations it seems to be the most recommeded and the most used one.
The programming language used was Java, even though I am not an expert at Java, I realized that a great deal of expertise is  not needed for the process as much of the process involves using predefined scripts and functiions provided by Selenium itself.

IMPORTANT NOTICES
1. The current example provided here is meant to work only on Google chrome browser, a much fuller test would use all browsers but this would require me to download all the drivers for all browser which I did not think was neccessary for just a sample.

2. Please remeber to place the Chrome driver in the C-Drive of the computer that you will be using for the tests, and all the attched JARS in the attachments folders otherwise it may not work.

3.Please select all JAR files in the selenium folder and the libs subfolder as external JARS to the project, in the add external JARS section of the Project Properties. 

3. During the interview, I think you mentioned having to download the files for the entire website, both back-end and front-end, this was not neccessary in the long run, since I only needed to test the front-end, and this could be done using the online-version (since it would be testing with "localhost" if I did that and would still require an angualr run).

I also could have provided more test cases, but the design of the website sice it was designed only for a school project that did not require automated testing, was lacking in a lot of areas such as unique "IDs" and "CLASSES" thus making the automates testing impossible in certain cases. 